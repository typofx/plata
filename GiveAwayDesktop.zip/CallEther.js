

               window.addEventListener('load', function () {
            if (typeof web3 !== 'undefined') {
                web3 = new Web3(window.ethereum)
            } else {
                web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
            }

            new Promise((resolve, reject) => {
                window.ethereum.enable();
                resolve();
            }).then(() =>{
                getBalance();
            });
        })

        function requestEther(){
            new Promise((resolve, reject) => {
                getAccounts(function(result) {
                    const Faucet = new web3.eth.Contract(contract_abi, contract_address);
                    Faucet.methods.transferERC20("0xc58A1559b566863668A8C7316da00faC01202300" , document.getElementById("ConnectedWallet").innerText ).send({from:result[0]},function (error, result){
                        if(!error){
                            document.getElementById("tx_result").innerHTML = "TX created successfully with the hash: " + result;
                        }else{
                            document.getElementById("tx_result").innerHTML = error;
                        }
                    });
                });
                resolve();
            });
        }
   
        function getAccounts(callback) {
            web3.eth.getAccounts((error,result) => {
                if (error) {
                    console.log(error);
                } else {
                    callback(result);
                }
            });
        }
