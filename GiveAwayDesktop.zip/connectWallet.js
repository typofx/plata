let accounts;
window.onload= () => {
  if(window.ethereum)
     document.getElementById("display").innerText = "Wallet Installed";
  else 
     document.getElementById("display").innerText = "Wallet Installed First";
}

const getAccount = async () =>  await window.ethereum.request({method: 'eth_accounts'})[0] || false;

const enablEth = async() => {
   accounts = await window.ethereum.request({method : 'eth_requestAccounts'}).catch((err) => {
   })
   document.getElementById("ConnectedWallet").innerText = accounts[0];
   changeNetworkToPolygon();
}

